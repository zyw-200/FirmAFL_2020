var BLANK_INVALID = false;
var SPACE_INVALID = false

//Frederick,070214	add disabling of all elements under 1 id given
DISABLED = true;
ENABLED = false;

var hexVals = new Array("0", "1", "2", "3", "4", "5", "6", "7", "8", "9",
              "A", "B", "C", "D", "E", "F");

function isNameUnsafe(compareChar) {
// Jerry 20040628, @ . is allow
//   var unsafeString = "\"<>%\\^[]`\+\$\,='#&@.: \t";
   var unsafeString = "\"<>%\\^[]`\+\$\,='#&: \t";
	
   if ( unsafeString.indexOf(compareChar) == -1 && compareChar.charCodeAt(0) > 32
        && compareChar.charCodeAt(0) < 123 )
      return false; // found no unsafe chars, return false
   else
      return true;
}   			  
			  
function isValidName(name,fieldname,isblankvalid,isSpaceValid) {
   var i = 0;	
   var hasField = false;

	if (fieldname != undefined) hasField = true;

   if (name=="")
	if ((isblankvalid == undefined) || (isblankvalid == false))
	{
		if (hasField)	alertInvalid(fieldname,name);
		return false;
	}
 
   if ((isSpaceValid == undefined) || (isSpaceValid == false)){	
	   for ( i = 0; i < name.length; i++ ) {
	      if ( isNameUnsafe(name.charAt(i)) == true )
		  {
			if (hasField)	alertInvalid(fieldname,name, "\nPlease do not use invalid characters(\"~<>%\\^[ ]`\+\$\,='#&:' ').");
	         return false;
		  }
	   }
	}
	else
	{
	   for ( i = 0; i < name.length; i++ ) {
		      if ( isCharUnsafe(name.charAt(i)) == true ){
				if (hasField)	alertInvalid(fieldname,name, "\nPlease do not use invalid characters(\"~<>%\\^[ ]`\+\$\,='#&@.:' ').");
        		 return false;
		   }
		}
	}
	

   return true;
}

function isCharUnsafe(compareChar) {
   var unsafeString = "\"<>%\\^[]`\+\$\,='#&@.:\t";
   if ( unsafeString.indexOf(compareChar) == -1 && compareChar.charCodeAt(0) >= 32
        && compareChar.charCodeAt(0) < 123 )
      return false; // found no unsafe chars, return false
   else
      return true;
}

function convertSpclChar (compareChar) {

	var i_ctr = 0;
	var toConvertString = "\"<>%\\^[]`\+\$\,='#&: \t";
	var returnString = "";	

	while (i_ctr < compareChar.length){

		if (toConvertString.indexOf(compareChar.charAt(i_ctr)) == -1)
			returnString = returnString + compareChar.charAt(i_ctr);			
		else
			returnString = returnString + convert(compareChar.charAt(i_ctr));			

		i_ctr++;
	}

	return returnString
}

function convert(val)
// this converts a given char to url hex form
{
   return  "%" + decToHex(val.charCodeAt(0), 16);
}

function alertInvalid(fieldname, fieldvalue, additional)
{
	if (additional == undefined)
		alert (fieldname + " " + fieldvalue + " is invalid");
	else
		alert (fieldname + " " + fieldvalue + " is invalid " + additional);
}

function decToHex(num, radix)
// part of the hex-ifying functionality
{
   var hexString = "";
   while ( num >= radix ) {
      temp = num % radix;
      num = Math.floor(num / radix);
      hexString += hexVals[temp];
   }
   hexString += hexVals[num];
   return reversal(hexString);
}

function reversal(s)
// part of the hex-ifying functionality
{
   var len = s.length;
   var trans = "";
   for (i = 0; i < len; i++)
      trans = trans + s.substring(len-i-1, len-i);
   s = trans;
   return s;
}
