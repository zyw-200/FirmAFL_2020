//Frederick,070214	add disabling of all elements under 1 id given
DISABLED = true;
ENABLED = false;

function isValidPort(port,fieldname) {
   var fromport = 0;
   var toport = 100;
   var hasField = false;

   if (fieldname != undefined) hasField = true;

   portrange = port.split(':');
   if ( portrange.length < 1 || portrange.length > 2 ) {
	{
	   if (hasField) alertInvalid(fieldname,port);
       return false;
	}
   }
   if ( isNaN(portrange[0]) )
	{
	   if (hasField) alertInvalid(fieldname,port);
       return false;
	}
   //fromport = parseInt(portrange[0]);
   fromport = (portrange[0] * 1);
   if ( portrange.length > 1 ) {
       if ( isNaN(portrange[1]) )
		{
	   if (hasField) alertInvalid(fieldname,port);
          return false;
	    }
       //toport = parseInt(portrange[1]);
		toport = (portrange[1] * 1);
       if ( toport <= fromport )
		{
	   if (hasField) alertInvalid(fieldname,port);
           return false;      
		}
   }
   
   if ( fromport < 1 || fromport > 65535 || toport < 1 || toport > 65535 )
	{
	   if (hasField) alertInvalid(fieldname,port);
       return false;
	}
   
   return true;
}

function alertInvalid(fieldname, fieldvalue, additional)
{
	if (additional == undefined)
		alert (fieldname + " " + fieldvalue + " is invalid");
	else
		alert (fieldname + " " + fieldvalue + " is invalid " + additional);
}