var ERROR_ENCODE_URL = "(E)(R)(R)(O)(R)!!(R)(O)(R)(R)(E)";

//Frederick,070214	add disabling of all elements under 1 id given
DISABLED = true;
ENABLED = false;

function isHexaDigit(digit) {
   var hexVals = new Array("0", "1", "2", "3", "4", "5", "6", "7", "8", "9",
                           "A", "B", "C", "D", "E", "F", "a", "b", "c", "d", "e", "f");
   var len = hexVals.length;
   var i = 0;
   var ret = false;

   for ( i = 0; i < len; i++ )
      if ( digit == hexVals[i] ) break;

   if ( i < len )
      ret = true;

   return ret;
}

function isValidKey(val, size, fieldname) {
   var ret = false;
   var len = val.length;
   var dbSize = size * 2;

	var addcomment1 = "Please enter 13 ASCII characters or 26 hexadecimal digits for a 128-bit WEP encryption key.";
	var addcomment2 = "Please enter 5 ASCII characters or 10 hexadecimal digits for a 64-bit WEP encryption key.";

   if ( len == size ) {
   	if(val.match(/[^\x00-\xff]/g))
   	{
   	     alert("Invalid Key Input, Please enter ASCII characters(except ',').");
   	     return ret;
   	} else {
   	   for ( i = 0; i < size; i++)
   	     if (val.charAt(i) == ','){
   	     	alert("Invalid Key Input, Please enter ASCII characters(except ',').");
   	        return ret;
   	     }
   	   if ( i == size)
   	   	ret = true;
   	}
   } else if ( len == dbSize ) {
      for ( i = 0; i < dbSize; i++ )
         if ( isHexaDigit(val.charAt(i)) == false )
            break;
      if ( i == dbSize )
         ret = true;
   } else
      ret = false;

	if (fieldname != undefined) //show error message if fieldname is available
	   if (ret == false){
		if (size == 5)
			alertInvalid (fieldname,val,addcomment2);
		else if (size == 13)
			alertInvalid (fieldname,val,addcomment1);
	   }

   return ret;
}

function isInteger(val)
{
	var i;

	val = val + ""; //need to convert to string because 0 is treat as ""
	
	if (val == "")
		return false;

	for (i=0; i<val.length; i++ )
	{
		ch = val.charAt(i);
		if( (ch==' ')||(ch=='\n')||(ch=='\t') )
			return false;
		if (isNaN(ch))
			return false;
	}
		
	return true;
}

function isInValidRange(s,low,high,fieldname) {

	if(isInteger(s) == false)
	{
		if (fieldname != undefined) alertInvalid(fieldname,s);
		return false;
	
	}

	s = parseInt(s,10);


 	if(s<low||s>high){
		if (fieldname != undefined) alert (fieldname + " " + s + " is out of range [" + low + "-" + high + "]");
    	return false;
	}
	else
		return true;

}

function alertInvalid(fieldname, fieldvalue, additional)
{
	if (additional == undefined)
		alert (fieldname + " " + fieldvalue + " is invalid");
	else
		alert (fieldname + " " + fieldvalue + " is invalid " + additional);
}

// add by jqzhou
/*
 * disable_form_field()
 * Enables or disables a form element.
*/
function disable_form_field(field, disable){
	if (disable !== true && disable !== false) {
		disable = !field.disabled;
        	}
	field.disabled = disable;
}

/*
 * config_method_selector()
*/
function LTrim(string){
	return string.replace(/^\s+|\s+$/g ,"");
}

/*
* is_blank()
* Returns true if value is blank or empty (i.e. "").
*/
function is_blank(value)
{
	value += "";
	return value.match(/^\s*$/) ? true : false;
}

/*
 * is_number()
 *      Returns true if a value represents a number, else return false.
 */
function is_number(value)
{
        value += "";
        return value.match(/^-?\d*\.?\d+$/) ? true : false;
}


/*
* random_PSK_Key()
*/
function random_PSK_Key()
{
	var string="1234567890abcdef";
	var pskKey="";
	
	for (i=0; i<64; i++)
	{
		var pos = parseInt(Math.random()*(15-0+0)+0);
		pskKey += string.charAt(pos);
	}
	
	return pskKey;
}

/*
* isValidWPAPskKey()
*/
function isValidWPAPskKey(val) {
	var ret = false;
	var len = val.length;
	var maxSize = 64;
	var minSize = 8;
	
	if ( len >= minSize && len < maxSize ){
	    if(val.match(/[^\x00-\xff]/g))
   	    {
   	        return ret;
   	    } else {
   	        for ( i = 0; i < len; i++)
   	        if (val.charAt(i) == ','){
   	           return ret;
   	        }
   	        if ( i == len)
   	   	   ret = true;
   	    }
	} else if ( len == maxSize ) {
		for ( i = 0; i < maxSize; i++ )
			if ( isHexaDigit(val.charAt(i)) == false )
				break;
		if ( i == maxSize )
			ret = true;
	} 
	else
		ret = false;
		
	return ret;
}
