//Frederick,070214	add disabling of all elements under 1 id given
DISABLED = true;
ENABLED = false;

//dns.html, lanqos.html, qos.html, scsrvcntr.html, vlan.html, wirelessadv.html, lan.html, time.html, wan.html, wirelesssetting.html
function changeBlockState(idname,status){
	var i,currentcolor;
	var OS = GetBrowserOS();
	var tempelems = document.getElementById(idname).getElementsByTagName("*");

	if (status == false)
		currentcolor = "black";			
	else
		currentcolor = "gray";

	for (i = 0; i < tempelems.length;i++){
		if("whiteTitle"==tempelems[i].id&&status==false)
		{
			tempelems[i].style.color = "white";
			continue;
		}
		else 
		{
		  if("whiteTitle"==tempelems[i].id&&status==true)
		  {
		     tempelems[i].style.color = "gray";
			 continue;
		  }
		}
		if (tempelems[i].disabled != undefined)
			tempelems[i].disabled = status;

	if (OS.indexOf("msie")!= -1){	//ie returns null, firefox uses undefined.....@#@%@^#@^	
		if (tempelems[i].style.color)
			tempelems[i].style.color = currentcolor;				
	}
	else{
		if (tempelems[i].style.color != undefined)
			tempelems[i].style.color = currentcolor;				
		}
	}
}

function GetBrowserOS()
{

	var detect = navigator.userAgent.toLowerCase();
	var OS,browser,version,total,thestring, browseVer;

	if (do_checkstr('konqueror'))
	{
		browser = "Konqueror";
		OS = "Linux";
	}
	else if (do_checkstr('safari')) browser = "safa";
	else if (do_checkstr('omniweb')) browser = "omni";
	else if (do_checkstr('opera')) browser = "oper";
	else if (do_checkstr('webtv')) browser = "webt";
	else if (do_checkstr('icab')) browser = "icab";
	else if (do_checkstr('msie')) browser = "msie";
	//Frederick,060721	Add firefox detection
	else if(navigator.userAgent.indexOf("Firefox")!=-1){
		var versionindex=navigator.userAgent.indexOf("Firefox")+8
		if (parseInt(navigator.userAgent.charAt(versionindex))>=1)
		browser = "fire";
	}
	else if (!do_checkstr('compatible'))
	{
		browser = "nets"
	}
		else browser = "unknown";

	if (browser != "unknown")
		if (!OS)
		{
			if (do_checkstr('linux')) OS = "lin";
			else if (do_checkstr('x11')) OS = "uni";
			else if (do_checkstr('mac')) OS = "mac"
			else if (do_checkstr('win')) OS = "win"
			else OS = "unknown";
		}

	browseVer = browser + OS;

	return browseVer;
}


function do_checkstr(string)
{
	var detect = navigator.userAgent.toLowerCase();
	place = detect.indexOf(string) + 1;
	thestring = string;
	return place;
}