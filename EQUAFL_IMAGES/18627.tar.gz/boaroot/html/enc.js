var ERROR_ENCODE_URL = "(E)(R)(R)(O)(R)!!(R)(O)(R)(R)(E)";

var hexVals = new Array("0", "1", "2", "3", "4", "5", "6", "7", "8", "9",
              "A", "B", "C", "D", "E", "F");
var unsafeString = "\"<>%\\^[]`\+\$\,'#&";
			  
function encodeUrl(val,fieldname)//wizpass.htm, wirelesssetting.html
{
   var len     = val.length;
   var i       = 0;
   var newStr  = "";
   var original = val;
   var hasField = false;

   if (fieldname != undefined ) hasField = true;

   for ( i = 0; i < len; i++ ) {
      if ( val.substring(i,i+1).charCodeAt(0) < 255 ) {
         // hack to eliminate the rest of unicode from this
         if (isUnsafe(val.substring(i,i+1)) == false)
            newStr = newStr + val.substring(i,i+1);
         else
            newStr = newStr + convert(val.substring(i,i+1));
      } else {
         // woopsie! restore.
         //alert ("Found a non-ISO-8859-1 character at position: " + (i+1) + ",\nPlease eliminate before continuing.");
         newStr = original;

		 if (hasField) {
		//	alertInvalid(fieldname,val,"contains non-ISO-8859-1 characters");
			alertInvalid(fieldname,val);
			newStr = ERROR_ENCODE_URL;
		 }

         // short-circuit the loop and exit
         i = len;
      }
   }

   return newStr;
}

function convert(val)
// this converts a given char to url hex form
{
   return  "%" + decToHex(val.charCodeAt(0), 16);
}

function isUnsafe(compareChar)
// this function checks to see if a char is URL unsafe.
// Returns bool result. True = unsafe, False = safe
{
   if ( unsafeString.indexOf(compareChar) == -1 && compareChar.charCodeAt(0) > 32
        && compareChar.charCodeAt(0) < 123 )
      return false; // found no unsafe chars, return false
   else
      return true;
}


function alertInvalid(fieldname, fieldvalue, additional)//wizpass.htm, wirelesssetting.html
{
	if (additional == undefined)
		alert (fieldname + " " + fieldvalue + " is invalid");
	else
		alert (fieldname + " " + fieldvalue + " is invalid " + additional);
}

function isPasswordUnsafe(compareChar) {//wizpass.htm
// Allison 070314, set password unsafe list as Dlink_UK's requirement
   var unsafeString = "\"%^\(\)\*\$\!&\t";
	
   if ( unsafeString.indexOf(compareChar) == -1 && compareChar.charCodeAt(0) > 32
        && compareChar.charCodeAt(0) < 123 )
      return false; // found no unsafe chars, return false
   else
      return true;
}

function decToHex(num, radix)
// part of the hex-ifying functionality
{
   var hexString = "";
   while ( num >= radix ) {
      temp = num % radix;
      num = Math.floor(num / radix);
      hexString += hexVals[temp];
   }
   hexString += hexVals[num];
   return reversal(hexString);
}

function reversal(s)
// part of the hex-ifying functionality
{
   var len = s.length;
   var trans = "";
   for (i = 0; i < len; i++)
      trans = trans + s.substring(len-i-1, len-i);
   s = trans;
   return s;
}
