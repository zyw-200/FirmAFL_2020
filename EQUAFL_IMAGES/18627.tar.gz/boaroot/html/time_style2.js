var dateTime = '7.04.2007,07:09:23 Wed';
var startYear=2007;
var manualConfigTime = '1';
var buildDaylight='1';


function parseDate(){
	var d = new Date(dateTime);
	if (isNaN(d.getDate())){
		return;
	}
	with (document.forms[0]) {
	    mnualMonth.selectedIndex = d.getMonth();
    	mnualDay.selectedIndex = d.getDate() - 1;
	    mnualHour.selectedIndex = d.getHours();
    	mnualMin.selectedIndex = d.getMinutes();
	    mnualSec.selectedIndex = d.getSeconds();
		if ((d.getFullYear() - startYear) >= 0)
			mnualYear.selectedIndex = d.getFullYear() - startYear;
	}
}

function btnGetSysDate()
{
	var d = new Date();
	with (document.forms[0]) {
        textSetupTimeSetSelectYear.selectedIndex = d.getFullYear() - startYear;
	    textSetupTimeSetSelectMonth.selectedIndex = d.getMonth();
    	textSetupTimeSetSelectDay.selectedIndex = d.getDate() - 1;
	    textSetupTimeSetSelectHour.selectedIndex = d.getHours();
    	textSetupTimeSetSelectMinute.selectedIndex = d.getMinutes();
	    textSetupTimeSetSelectSecond.selectedIndex = d.getSeconds();
	}
}

function setTimeParam() {
	var DSTPeriodFlag = 0;		
	if (document.forms[0].startMonth.selectedIndex > document.forms[0].endMonth.selectedIndex){
		DSTPeriodFlag = 1;
	}else if (document.forms[0].startMonth.selectedIndex == document.forms[0].endMonth.selectedIndex){
		if (document.forms[0].startWeek.selectedIndex > document.forms[0].endWeek.selectedIndex){
			DSTPeriodFlag = 1;
		}else if (document.forms[0].startWeek.selectedIndex == document.forms[0].endWeek.selectedIndex) {
			if (document.forms[0].startDay.selectedIndex > document.forms[0].endDay.selectedIndex) {
				DSTPeriodFlag = 1;					
			} else if (document.forms[0].startDay.selectedIndex == document.forms[0].endDay.selectedIndex) {
				if (Number(document.forms[0].startTime.value) > Number(document.forms[0].endTime.value)) {
					DSTPeriodFlag = 1;				
				}
			}
		}
	}
	if (DSTPeriodFlag == 1)
	{
		alert("start time should be earlier than end time");
		return false;	
	}	

	document.forms[0].daylight.value = document.forms[0].textSetupTimeDaylightCheck.checked == true ? "Enable" : "Disable";
	document.forms[0].setupTimeServer.value = document.forms[0].textSetupTimeServercheck.checked == true ? "0" : "2";
	
	if(document.forms[0].setupTimeServer.value==0)
	{
		var objntpserver1=document.forms[0].textSetupTimeServerIP;
		if(document.forms[0].sel_NTPSERVER.selectedIndex==document.forms[0].sel_NTPSERVER.options.length-1)
		{
			if(objntpserver1.value.length == 0 ) { 
				alert('First time server is other, but Other field is blank');
				return;
			} 
			else if(!isValidName(objntpserver1.value, "First time server")){        
				return;
			} 
			else if (isSrv_new(objntpserver1.value)== true){  // add by jack,2008.7.16
				alert ("First time server is not an legal ntp server!");
				return;
			}		
			else {
				document.forms[0].hid_NTPServerIP.value=document.forms[0].textSetupTimeServerIP.value;
			}
		}
		else
			document.forms[0].hid_NTPServerIP.value=document.forms[0].sel_NTPSERVER.value;
		
		var objNtpServer2=document.forms[0].textSetupTimeServerIP2;
		if(document.forms[0].sel_NTPSERVER2.selectedIndex==document.forms[0].sel_NTPSERVER2.options.length-1)
		{
			if(objNtpServer2.value.length == 0) { // == Other
			          alert('Second time server is other, but Other field is blank');
			          return;
		        } 
		        else if(!isValidName(objNtpServer2.value, "Second tome server")){        
		 		return;
		        } 
		        else if (isSrv_new(objNtpServer2.value)== true){  // add by jack,2008.7.16
				alert ("Second time server is not an legal ntp server!");
				return;
			}
			else 
			{
		        	document.forms[0].hid_NTPServerIP2.value=document.forms[0].textSetupTimeServerIP2.value;
		        }
		}
		else
			document.forms[0].hid_NTPServerIP2.value=document.forms[0].sel_NTPSERVER2.value;	
	}
	
	return true;
}

function changePageStatus(idname,state)
{
	var tempElemt=document.getElementById(idname);
	var selectList=tempElemt.getElementsByTagName("select");
	for(i=0;i<selectList.length;i++)
		selectList[i].disabled=state;
	var textareaList=tempElemt.getElementsByTagName("textarea");
	for(i=0;i<textareaList.length;i++)
		textareaList[i].disabled=state;
	var inputList=tempElemt.getElementsByTagName("input");
	for(i=0;i<inputList.length;i++)
		inputList[i].disabled=state;				
}
function hideNtpConfig(hide) {
  var status = false;

   if (hide){
	 changePageStatus("autotime",DISABLED);
	 changePageStatus("tby_timeconf",DISABLED); 
	 changePageStatus("manualtime",ENABLED);
	}
   else{
	 changePageStatus("autotime",ENABLED);
	 changePageStatus("tby_timeconf",ENABLED);
	 changePageStatus("manualtime",DISABLED);
	 if(document.forms[0].textSetupTimeDaylightCheck.checked != true)
	 {
	 	 changePageStatus("daylight_opt",DISABLED);
	 }
	 if(document.forms[0].sel_NTPSERVER.selectedIndex==document.forms[0].sel_NTPSERVER.length-1)
	 {
	 	document.forms[0].textSetupTimeServerIP.disabled=false;
	 	document.forms[0].textSetupTimeServerIP.value=document.forms[0].hid_NTPServerIP.value;
	 }
	 else
	 	document.forms[0].textSetupTimeServerIP.disabled=true;
	 	
	 if(document.forms[0].sel_NTPSERVER2.selectedIndex==document.forms[0].sel_NTPSERVER2.length-1)
	 {
	 	document.forms[0].textSetupTimeServerIP2.disabled=false;
	 	document.forms[0].textSetupTimeServerIP2.value=document.forms[0].hid_NTPServerIP2.value;
	 }
	 else
	 	document.forms[0].textSetupTimeServerIP2.disabled=true;		 
   }
}

function ntpEnblChange() {
  if( document.forms[0].textSetupTimeServercheck.checked )
    hideNtpConfig(0);
  else
    hideNtpConfig(1);
}

function getSelectIndex(optionlist,val) {
  var i = 0;
  var ret=0;

  for ( i = 0; i < optionlist.length; i++ ) {
    if ( optionlist[i].value == val )
      break;
  }
  if ( i < optionlist.length )
    ret = i;
  return ret;
}

function changeDST(){
  var status = true;
  with (document.forms[0]) {
	if (textSetupTimeDaylightCheck.checked == true)
	  changePageStatus("daylight_opt",ENABLED);
	else
	  changePageStatus("daylight_opt",DISABLED);
  }

}

var whichDayNum;
var BigMon=new Array('1','3','5','7','8','10','12');
var SmallMon=new Array('4','6','9','11');
var Hour, Min, Sec;
var Year, Mon, Day;
function IncreaseSec()
{
        Sec = parseInt(document.forms[0].mtenCurrent_Sec.value);
        Sec = Sec + 1;
        if ( Sec < 60 )
        {
			document.forms[0].mtenCurrent_Date.value = Year + "-"+ DateAndTimeFormat(Mon) +"-" + DateAndTimeFormat(Day);
            document.forms[0].mtenCurrent_Time.value = DateAndTimeFormat(Hour) + ":"+ DateAndTimeFormat(Min) +":" + DateAndTimeFormat(Sec);
            document.forms[0].mtenCurrent_Sec.value = Sec;
            setTimeout('IncreaseSec()', 1000);
            return ;
        }
        
        document.forms[0].mtenCurrent_Sec.value = 0;Sec=0;
        Min = parseInt(document.forms[0].mtenCurrent_Min.value);
        Min = Min + 1;
        if ( Min < 60 )
        {
			document.forms[0].mtenCurrent_Date.value = Year + "-"+ DateAndTimeFormat(Mon) +"-" + DateAndTimeFormat(Day);
            document.forms[0].mtenCurrent_Time.value = DateAndTimeFormat(Hour) + ":"+ DateAndTimeFormat(Min) +":" + DateAndTimeFormat(Sec);
            document.forms[0].mtenCurrent_Min.value = Min;
            setTimeout('IncreaseSec()', 1000);
            return;
        }
	
        document.forms[0].mtenCurrent_Min.value = 0;Min=0;
        Hour = parseInt(document.forms[0].mtenCurrent_Hour.value);
        Hour = Hour + 1;
        if ( Hour < 24 )
        {
			document.forms[0].mtenCurrent_Date.value = Year + "-"+ DateAndTimeFormat(Mon) +"-" + DateAndTimeFormat(Day);
            document.forms[0].mtenCurrent_Time.value = DateAndTimeFormat(Hour) + ":"+ DateAndTimeFormat(Min) +":" + DateAndTimeFormat(Sec);
            document.forms[0].mtenCurrent_Hour.value = Hour;
            setTimeout('IncreaseSec()', 1000);
            return;
        }
        document.forms[0].mtenCurrent_Time.value = "00 : 00 : 00";
        document.forms[0].mtenCurrent_Hour.value = 0;Hour=0;
        Day = parseInt(document.forms[0].mtenCurrent_Day.value);
        Day = Day + 1;        
        Mon = parseInt(document.forms[0].mtenCurrent_Mon.value);
        Year = parseInt(document.forms[0].mtenCurrent_Year.value);
		
		for(var i=0;i<BigMon.length;i++)
			if(Mon.value==BigMon[i]) whichDayNum=31;
		for(var i=0;i<SmallMon.length;i++)
			if(Mon.value==SmallMon[i]) whichDayNum=30;
		if((Year.value%4)==0)
			whichDayNum=29;
		else
			whichDayNum=28;
		
        if ( Day <= whichDayNum )
        {
	    	document.forms[0].mtenCurrent_Date.value = Year + "-"+ DateAndTimeFormat(Mon) +"-" + DateAndTimeFormat(Day);
			document.forms[0].mtenCurrent_Time.value = DateAndTimeFormat(Hour) + ":"+ DateAndTimeFormat(Min) +":" + DateAndTimeFormat(Sec);
            document.forms[0].mtenCurrent_Day.value = Day;
            setTimeout('IncreaseSec()', 1000);
            return;
		}
		
        document.forms[0].mtenCurrent_Day.value = 1;Day=1;
        Mon = parseInt(document.forms[0].mtenCurrent_Mon.value);
        Mon = Mon + 1;

        if ( Mon <= 12 )
        {
	    	document.forms[0].mtenCurrent_Date.value = Year + "-"+ DateAndTimeFormat(Mon) +"-" + DateAndTimeFormat(Day);
			document.forms[0].mtenCurrent_Time.value = DateAndTimeFormat(Hour) + ":"+ DateAndTimeFormat(Min) +":" + DateAndTimeFormat(Sec);
            document.forms[0].mtenCurrent_Mon.value = Mon;
            setTimeout('IncreaseSec()', 1000);
            return;
		}

        document.forms[0].mtenCurrent_Mon.value = 1;Mon=1;
        Year = parseInt(document.forms[0].mtenCurrent_Year.value);
        Year = Year + 1;

        if ( Year < 10000)
        {
	   		document.forms[0].mtenCurrent_Date.value = Year + "-"+ DateAndTimeFormat(Mon) +"-" + DateAndTimeFormat(Day);
			document.forms[0].mtenCurrent_Time.value = DateAndTimeFormat(Hour) + ":"+ DateAndTimeFormat(Min) +":" + DateAndTimeFormat(Sec);
            document.forms[0].mtenCurrent_Year.value = Year;
            setTimeout('IncreaseSec()', 1000);
            return;
		}
        document.forms[0].mtenCurrent_Year.value = 1900;Year=1900;
        this.location = "/cgi-bin/rpTimeZone.asp";
        return;
}
function initDateAndTime()
{
	Hour=parseInt(document.forms[0].mtenCurrent_Hour.value);
	Min=parseInt(document.forms[0].mtenCurrent_Min.value);
	Sec=parseInt(document.forms[0].mtenCurrent_Sec.value);
	Year=parseInt(document.forms[0].mtenCurrent_Year.value);
	Mon=parseInt(document.forms[0].mtenCurrent_Mon.value);
	Day=parseInt(document.forms[0].mtenCurrent_Day.value);
        document.forms[0].mtenCurrent_Time.value = DateAndTimeFormat(Hour) + ":"+ DateAndTimeFormat(Min) +":" + DateAndTimeFormat(Sec);
        document.forms[0].mtenCurrent_Date.value = Year + "-"+ DateAndTimeFormat(Mon) +"-" + DateAndTimeFormat(Day);
}
function DateAndTimeFormat(num)
{
	if(String(num).length == 1)
		return "0"+num;
	else 
		return num;
}
function getCurTime(){
	var monthHash = {
		m01 : "January",
		m02 : "February",
		m03 : "March",
		m04 : "April",
		m05 : "May",
		m06 : "June",
		m07 : "July",
		m08 : "August",
		m09 : "September",
		m10 : "October",
		m11 : "November",
		m12 : "December"
	}
	var weekDayHash = {
		0 : "Sunday",
		1 : "Monday",
		2 : "Tuesday",
		3 : "Wednesday",
		4 : "Thursday",
		5 : "Friday",
		6 : "Saturday"
	}
	var dateArr = document.forms[0].mtenCurrent_Date.value.split("-");
	var monthKey = "m"+dateArr[1];
	var curMonth = monthHash[monthKey];
	var curYear = dateArr[0];
	var curDay = dateArr[2];
	var curDate = curMonth + " " + curDay + ", " + curYear + " ";
	var Hour=parseInt(document.forms[0].mtenCurrent_Hour.value);
	var show_AM_PM=(Hour>=12) ? "PM" : "AM";
	var show_weekday=weekDayHash[new Date(dateArr[0]+"/"+dateArr[1]+"/"+dateArr[2]).getDay()];
	document.getElementById("spanCurTime").innerHTML = show_weekday+", "+curDate + document.forms[0].mtenCurrent_Time.value + " " +show_AM_PM;
	setTimeout('getCurTime()', 1000);
}

function changeDay(){
	var year = document.forms[0].textSetupTimeSetSelectYear.value;
	var month = document.forms[0].textSetupTimeSetSelectMonth.value;
	var objDay = document.forms[0].textSetupTimeSetSelectDay;
	createDay(year,month,objDay);
}

function createDay(year,month,objDay){
	var i;
	var day = new Date(year,month,0);
	var maxDays = day.getDate();
	objDay.options.length = 0;
	for(i=1;i<=maxDays;i++){
		var item = new Option(i, i);
		objDay.options.add(item);
	}
}

function setNTPServer(obj)
{
	if(obj.selectedIndex!=(obj.options.length-1))
	{
		document.forms[0].textSetupTimeServerIP.value="";
		document.forms[0].textSetupTimeServerIP.disabled=true;
	}
	else
		document.forms[0].textSetupTimeServerIP.disabled=false;
}

function setNTPServer2(obj)
{
	if(obj.selectedIndex!=(obj.options.length-1))
	{
		document.forms[0].textSetupTimeServerIP2.value="";
		document.forms[0].textSetupTimeServerIP2.disabled=true;
	}	
	else
		document.forms[0].textSetupTimeServerIP2.disabled=false;
}

function InitDaylight()
{
	 changeDST();
	 setSelectInit(document.forms[0].startMonth,document.forms[0].hid_startMonth.value);
	 setSelectInit(document.forms[0].startWeek,document.forms[0].hid_startWeek.value);
	 setSelectInit(document.forms[0].startDay,document.forms[0].hid_startDay.value);
	 setSelectInit(document.forms[0].startTime,document.forms[0].hid_startTime.value);
	 setSelectInit(document.forms[0].endMonth,document.forms[0].hid_endMonth.value);
	 setSelectInit(document.forms[0].endWeek,document.forms[0].hid_endWeek.value);
	 setSelectInit(document.forms[0].endDay,document.forms[0].hid_endDay.value);
	 setSelectInit(document.forms[0].endTime,document.forms[0].hid_endTime.value);	 	
}

function setSelectInit(obj,value)
{
	for(i=0;i<obj.options.length;i++)
	{
		if(value==obj.options[i].value)
		{
			obj.options[i].selected;
			return;
		}
	}
}
