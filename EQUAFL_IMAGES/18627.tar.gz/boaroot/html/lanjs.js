var TYPE_NETWORK_ADDRESS = "NETWORK";
var TYPE_IP_ADDRESS = "IP";
var TYPE_BRCAST_ADDRESS = "BROADCAST";

//Frederick,070214	add disabling of all elements under 1 id given
DISABLED = true;
ENABLED = false;

function isSameSubNet(lan1Ip, lan1Mask, lan2Ip, lan2Mask) {

   var count = 0;
   
   lan1a = lan1Ip.split('.');
   lan1m = lan1Mask.split('.');
   lan2a = lan2Ip.split('.');
   lan2m = lan2Mask.split('.');

   for (i = 0; i < 4; i++) {
      l1a_n = parseInt(lan1a[i], 10);
      l1m_n = parseInt(lan1m[i], 10);
      l2a_n = parseInt(lan2a[i], 10);
      l2m_n = parseInt(lan2m[i], 10);
      if ((l1a_n & l1m_n) == (l2a_n & l2m_n))
         count++;
   }
   if (count == 4)
      return true;
   else
      return false;
}

function isValidIpAddress(address,fieldname,type) {
   var i = 0;
   var c = '';
   var hasfield = false;
	
   if (fieldname != undefined)	hasfield = true;
	   

   if (address == "") {
       if (hasfield) alertInvalid(fieldname,address);
	   return false;
  }

   for (i = 0; i < address.length; i++) {
     c = address.charAt(i);
     if((c>='0'&&c<='9')||(c=='.'))
       continue;
     else	
	 {
       if (hasfield) alertInvalid(fieldname,address);
	   return false;
  	  }
   }
   if ( address == '0.0.0.0' ||
        address == '255.255.255.255' )
	 {
       if (hasfield) alertInvalid(fieldname,address);
      return false;
	 }

   addrParts = address.split('.');

	//Frederick,060724	Make sure that everything is in decimal place
	for (i=0; i < addrParts.length; i++){
		addrParts[i] = parseInt(addrParts[i],10);
		addrParts[i] += "";
	}

   if ( addrParts.length != 4 ) 	 {
       if (hasfield) alertInvalid(fieldname,address);
		return false;
	}

   for (i = 0; i < 4; i++) {
      if (isNaN(addrParts[i]) || addrParts[i] =="")
	 {
       if (hasfield) alertInvalid(fieldname,address);
         return false;
	 }
      num = parseInt(addrParts[i],10);
      if ( num < 0 || num > 255 )
	 {
       if (hasfield) alertInvalid(fieldname,address);
         return false;
	 }
	  if (addrParts[i].length > 3)
	 {
       if (hasfield) alertInvalid(fieldname,address);
		return false;
	 }
   }
	if (parseInt(addrParts[0],10)==127||parseInt(addrParts[0],10)>223)
	{
		if (hasfield) alertInvalid(fieldname,address);
   		return false;
	}


	if ((type == undefined) || (type==TYPE_IP_ADDRESS))
	   if (parseInt(addrParts[0],10)==0||parseInt(addrParts[3],10)==0)
		 {
	       if (hasfield) alertInvalid(fieldname,address);
   			return false;
		 }
	else 
		if (type == TYPE_NETWORK_ADDRESS)
			if (parseInt(addrParts[0],10)==0)
			 {
		       if (hasfield) alertInvalid(fieldname,address);
   				return false;
			 }

   return true;
}

function getLeftMostZeroBitPos(num) {
   var i = 0;
   var numArr = [128, 64, 32, 16, 8, 4, 2, 1];

   for ( i = 0; i < numArr.length; i++ )
      if ( (num & numArr[i]) == 0 )
         return i;

   return numArr.length;
}

function getRightMostOneBitPos(num) {
   var i = 0;
   var numArr = [1, 2, 4, 8, 16, 32, 64, 128];

   for ( i = 0; i < numArr.length; i++ )
      if ( ((num & numArr[i]) >> i) == 1 )
         return (numArr.length - i - 1);

   return -1;
}

function isValidSubnetMask(mask,fieldname) {
   var i = 0, num = 0;
   var zeroBitPos = 0, oneBitPos = 0;
   var zeroBitExisted = false;
   var c = '';
   var hasField = false;

   if (fieldname != undefined) hasField = true;

   for (i = 0; i < mask.length; i++) {
     c = mask.charAt(i);
     if((c>='0'&&c<='9')||(c=='.'))
       continue;
     else
	 {
	   if (hasField) alertInvalid(fieldname,mask);
       return false;
	 }
   }
   if ( mask == '0.0.0.0' )
	 {
	   if (hasField) alertInvalid(fieldname,mask);
      return false;
	 }

   maskParts = mask.split('.');
   if ( maskParts.length != 4 )
	 {
	   if (hasField) alertInvalid(fieldname,mask);
		 return false; //Frederick 060503, this part is buggy, an entry of 255.255.255. will not be detected
	  }

	//Frederick, 060503	check that every single digit is not blank{
	for (i=0; i<maskParts.length; i++)
		if (maskParts[i].length < 1){
	   if (hasField) alertInvalid(fieldname,mask);
			return false;
		}
	//Frederick, 060503	check that every single digit is not blank}

   for (i = 0; i < 4; i++) {
      if ( isNaN(maskParts[i]) == true ){
	   if (hasField) alertInvalid(fieldname,mask);
         return false;
		}
      num = parseInt(maskParts[i]);
      if ( num < 0 || num > 255 )	 {
	   if (hasField) alertInvalid(fieldname,mask);
         return false;
		}
      if ( zeroBitExisted == true && num != 0 )	 {
	   if (hasField) alertInvalid(fieldname,mask);
         return false;
		}
      zeroBitPos = getLeftMostZeroBitPos(num);
      oneBitPos = getRightMostOneBitPos(num);
      if ( zeroBitPos < oneBitPos )	 {
	   if (hasField) alertInvalid(fieldname,mask);
         return false;
		}
      if ( zeroBitPos < 8 )
         zeroBitExisted = true;
   }
   if (parseInt(maskParts[0])==0)	 {
	   if (hasField) alertInvalid(fieldname,mask);
   	return false;
		}

   if (parseInt(maskParts[3])>=255)	 {
	   if (hasField) alertInvalid(fieldname,mask);
   	return false;
		}

   return true;
}

function isInValidRange(s,low,high,fieldname) {

	if(isInteger(s) == false)
	{
		if (fieldname != undefined) alertInvalid(fieldname,s);
		return false;
	
	}

	s = parseInt(s,10);


 	if(s<low||s>high){
		if (fieldname != undefined) alert (fieldname + " " + s + " is out of range [" + low + "-" + high + "]");
    	return false;
	}
	else
		return true;

}

function reencodeIP (IP)
{
	var newIP = '';
	addrParts = IP.split('.');

	//Frederick,060724	Make sure that everything is in decimal place
	for (i=0; i < addrParts.length; i++)
		if (i == 3)
			newIP = newIP + parseInt(addrParts[i],10);
		else
			newIP = newIP + parseInt(addrParts[i],10) + '.';
		
	return newIP;
}

function isOverlapModemIp(EndIp, StartIp, ModemIp)
{
   addrEnd = EndIp.split('.');
   addrStart = StartIp.split('.');
   addrModem = ModemIp.split('.');
	E = parseInt(addrEnd[3],10) + 1;
    S = parseInt(addrStart[3],10) + 1;
	M = parseInt(addrModem[3],10) + 1;

	//it is assumed that end ip and start ip lie in the same subnet as checked by previous validation
	//check that modem ip it doesn't lie within ip range
	
	if ((S<=M) && (M<=E))
		return true;
	else
		return false;
}

function alertInvalid(fieldname, fieldvalue, additional)
{
	if (additional == undefined)
		alert (fieldname + " " + fieldvalue + " is invalid");
	else
		alert (fieldname + " " + fieldvalue + " is invalid " + additional);
}

function DoValidateIpRange(Subnet, Mask, type)
{
  var Subadd = Subnet.match("^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$");
  var Maskadd = Mask.match("^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$");

	//do not do anything if required parameters are not specified
	if ((Subnet == "") || (Mask =="")) return true;

  var i;
  var error=false;
  var count = 0;

    var snm1a = 255;
    var snm2a = 255;
    var snm3a = 255;
    var snm4a = 255;

    var nw1a = 0;
    var nw2a = 0;
    var nw3a = 0;
    var nw4a = 0;

    var broad1a = 255;
    var broad2a = 255;
    var broad3a = 255;
    var broad4a = 255;

	arrSubadd = Subadd[0].split(".");
  	arrMask = Maskadd[0].split(".");

    snm1a = arrMask[0];
    snm2a = arrMask[1];
    snm3a = arrMask[2];
    snm4a = arrMask[3];

    var ck1a = arrSubadd[0];
    var ck2a = arrSubadd[1];
    var ck3a = arrSubadd[2];
    var ck4a = arrSubadd[3];

  	nw1a = eval(snm1a & ck1a);
	nw2a = eval(snm2a & ck2a);
	nw3a = eval(snm3a & ck3a);
	nw4a = eval(snm4a & ck4a);

	broad1a = ((nw1a) ^ (~ snm1a) & 255);
	broad2a = ((nw2a) ^ (~ snm2a) & 255);
	broad3a = ((nw3a) ^ (~ snm3a) & 255);
	broad4a = ((nw4a) ^ (~ snm4a) & 255);

	if ((type == undefined) || (type == TYPE_IP_ADDRESS)){
		if ((broad1a == arrSubadd[0]) && (broad2a == arrSubadd[1]) && (broad3a == arrSubadd[2]) && (broad4a == arrSubadd[3]))
		{
			errVal = "IP:" + Subnet + " Mask:" + Mask;
			alertInvalid("",errVal,"Please check your subnet mask");
			return false;
		}

	}
	else if (type == TYPE_NETWORK_ADDRESS){
		var tempIP = nw1a + "." + nw2a + "." + nw3a + "." + nw4a;
		if (tempIP != Subnet){
			errVal = Subnet + " Mask:" + Mask;		
			alertInvalid ("Network Address",errVal);
			return false;
		}
	}
	else if (type == TYPE_BRCAST_ADDRESS){
		var tempIP = broad1a + "." + broad2a + "." + broad3a + "." + broad4a;
		if (tempIP != Subnet)
			return false;
	}
  return true;
}

function DoValidateNetworkIP(Subnet, Mask)
{
  var Subadd = Subnet.match("^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$");
  var Maskadd = Mask.match("^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$");

	//do not do anything if required parameters are not specified
	if ((Subnet == "") || (Mask =="")) return true;

 var i;
  var error=false;
  var count = 0;

    var snm1a = 255;
    var snm2a = 255;
    var snm3a = 255;
    var snm4a = 255;

    var nw1a = 0;
    var nw2a = 0;
    var nw3a = 0;
    var nw4a = 0;

    var broad1a = 255;
    var broad2a = 255;
    var broad3a = 255;
    var broad4a = 255;

	arrSubadd = Subadd[0].split(".");
  	arrMask = Maskadd[0].split(".");

    snm1a = arrMask[0];
    snm2a = arrMask[1];
    snm3a = arrMask[2];
    snm4a = arrMask[3];

    var ck1a = arrSubadd[0];
    var ck2a = arrSubadd[1];
    var ck3a = arrSubadd[2];
    var ck4a = arrSubadd[3];

  	nw1a = eval(snm1a & ck1a);
	nw2a = eval(snm2a & ck2a);
	nw3a = eval(snm3a & ck3a);
	nw4a = eval(snm4a & ck4a);

	broad1a = ((nw1a) ^ (~ snm1a) & 255);
	broad2a = ((nw2a) ^ (~ snm2a) & 255);
	broad3a = ((nw3a) ^ (~ snm3a) & 255);
	broad4a = ((nw4a) ^ (~ snm4a) & 255);
	
	var tempIP = nw1a + "." + nw2a + "." + nw3a + "." + nw4a;
	
	if (tempIP == Subnet){
		errVal = Subnet + " Mask:" + Mask;		
		alertInvalid ("Network Address",errVal);
		return false;
	}	
  return true;
}

function getBroadcastIP(HostIp, Mask)
{
  var Hostadd = HostIp.match("^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$");
  var Maskadd = Mask.match("^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$");
  var digits1, digits3;
  var result;
  var count = 0;

    var oct1a = 0;
    var oct2a = 0;
    var oct3a = 0;
    var oct4a = 0;

    var snm1a = 255;
    var snm2a = 255;
    var snm3a = 255;
    var snm4a = 255;

    var nw1a = 0;
    var nw2a = 0;
    var nw3a = 0;
    var nw4a = 0;

    var broad1a = 255;
    var broad2a = 255;
    var broad3a = 255;
    var broad4a = 255;

    digits1 = Hostadd[0].split(".");
    digits3 = Maskadd[0].split(".");
	
    oct1a = digits1[0];
    oct2a = digits1[1];
    oct3a = digits1[2];
    oct4a = digits1[3];

    snm1a = digits3[0];
    snm2a = digits3[1];
    snm3a = digits3[2];
    snm4a = digits3[3];

  	nw1a = eval(snm1a & oct1a);
	nw2a = eval(snm2a & oct2a);
	nw3a = eval(snm3a & oct3a);
	nw4a = eval(snm4a & oct4a);
	broad1a = ((nw1a) ^ (~ snm1a) & 255);
	broad2a = ((nw2a) ^ (~ snm2a) & 255);
	broad3a = ((nw3a) ^ (~ snm3a) & 255);
	broad4a = ((nw4a) ^ (~ snm4a) & 255);

	result = broad1a + "." + broad2a + "." + broad3a + "." + broad4a

  return result;
}