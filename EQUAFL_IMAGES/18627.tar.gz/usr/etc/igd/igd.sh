#!/bin/sh
/sbin/upnpd &
