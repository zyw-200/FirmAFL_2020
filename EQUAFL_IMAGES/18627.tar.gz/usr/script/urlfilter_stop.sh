#!/bin/sh

# wtw add ifl7 iptables -F URL_FLT