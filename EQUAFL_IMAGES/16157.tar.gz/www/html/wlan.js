function key_value(cf)
{
	getObj("weppassphrase_id").value=document.getElementsByName("weppassphrase")[0].value;
	getObj("key1_id").value=document.getElementsByName("wepkey1")[0].value;
	getObj("key2_id").value=document.getElementsByName("wepkey2")[0].value;
	getObj("key3_id").value=document.getElementsByName("wepkey3")[0].value;
	getObj("key4_id").value=document.getElementsByName("wepkey4")[0].value;
	getObj("textWpaPwdPhrase1").value=document.getElementsByName("sec_wpaphrase1")[0].value;
	getObj("textWpaPwdPhrase2").value=document.getElementsByName("sec_wpaphrase2")[0].value;
	getObj("textWpaPwdPhrase3").value=document.getElementsByName("sec_wpaphrase3")[0].value;
}
function sectype(wl_sectype)
{
    if(wl_sectype==2)
	wl_sectype="WEP";
	else if(wl_sectype==3)
	wl_sectype="WPA-PSK";
	else if(wl_sectype==4)
	wl_sectype="WPA2-PSK";
	else if(wl_sectype==5)
	wl_sectype="WPA/WPA2-PSK";
	else
	wl_sectype="NONE";
		
}

function match_security_mode(cf)
{    
	cf.time_stamp_dni.value=parent.index_ts;
	var browser=eval ( '"' + top.location + '"' );
	
	if  ( lan_dhcp == 1 && dns_hijack != 1 )
	{
		judge_browser_nochange(cf,browser);
	}
    if(parent.ap_list_reset=="manual")
		location.href="ca_apclient_manual.html";
	else
	{
		var each_info= parent.ap_list_reset;
		each_info[1]=each_info[1].replace(/&lt;/g,'<');
		each_info[1]=each_info[1].replace(/&gt;/g,'>');
		get_before=each_info[4].split('|');
	    each_info[4]=get_before[0];
	    if(each_info[4]=="WPA/WPA2-PSK" || each_info[4]=="WPA-PSK" || each_info[4]=="WPA2-PSK")
			location.href="ca_apclient_wl_wpa.html";
		else if(each_info[4]=="WEP")
			location.href="ca_apclient_wl_wep.html";
		else
			 {
				 //each_info[1]=each_info[1].replace(/&lt;/g,'<');
				 //each_info[1]=each_info[1].replace(/&gt;/g,'>');
         if(each_info[1] == "&nbsp;&nbsp;")
         		location.href="ca_apclient_manual.html";
         else
				 {
            if(each_info[4]=="OFF")
            {
               cf.hidden_sec_ap_type.value=1;
               cf.wlan_ap_wifi.value=each_info[1];
               if (dns_hijack==1)
               {
               		var len=each_info[1].length;
										if(len>28)
											each_info[1]=each_info[1].substring(0,28);
               		document.forms[0].wlan_ca_ap_wifi.value= each_info[1] + "_EXT";
               }
               cf.submit_flag.value="ca_ap_wlan";
               if(dns_hijack==0)
                  cf.action="/cgi-bin/setobject.cgi?/cgi-bin/wait_for_ca_connect.html";
               else
                  cf.action="/cgi-bin/setobject.cgi?/cgi-bin/ca_ap_settings.html";
             }
             cf.submit();
          }
        }
   }
}

function retry_set_passphrase(cf)
{
	cf.time_stamp_dni.value=parent.index_ts;
	cf.submit_flag.value="retry_set_passph";
	var keytype;
	if(dns_hijack==1)
		cf.action="/cgi-bin/setobject.cgi?/cgi-bin/ca_ap_settings.html";
	else
		cf.action="/cgi-bin/setobject.cgi?/cgi-bin/ca_connect_rightpage.html";
	var browser=eval ( '"' + top.location + '"' );
	
	if  ( lan_dhcp == 1 && dns_hijack != 1)
	{
		judge_browser_nochange(cf,browser);
	}
		if(cf.hidden_sec_ap_type.value==2)
	    {
			if(checkwep_byid(cf)==false)
				return false;
	        cf.hidden_sec_ap_type.value=2;
			cf.ap_sec_wpaphrase_len.value=cf.ap_sec_phrase.length;
			cf.ap_sec_keylen.value=getObj("keylen_id").value;
			cf.ap_wepkey1.value=getObj("key1_id").value;
			cf.ap_wepkey2.value=getObj("key2_id").value;
			cf.ap_wepkey3.value=getObj("key3_id").value;
			cf.ap_wepkey4.value=getObj("key4_id").value;
			cf.ap_sec_phrase.value=getObj("weppassphrase_id").value;
			var len1=document.getElementById("key1_id").value.length;
			var len2=document.getElementById("key2_id").value.length;
			var len3=document.getElementById("key3_id").value.length;
			var len4=document.getElementById("key4_id").value.length;
			if(getObj("keylen_id").value == 5)
				keytype=5;
			else
				keytype=13;
			
				for(i=0;i<keytype;i++)
				{
					if(((getObj('wepkeyno_id1').checked == true) && (len1 == keytype)) || ((getObj('wepkeyno_id2').checked == true) && (len2 == keytype)) || ((getObj('wepkeyno_id3').checked == true) && (len3 == keytype)) || ((getObj('wepkeyno_id4').checked == true) && (len4 == keytype)))
						cf.key_type.value=1;
					else
						cf.key_type.value=0;
				}
	        cf.submit();
	    }
		else if (cf.hidden_sec_ap_type.value!=1)
		{        
	        if( checkpsk_ca_fixed(cf)== false)
	            return false;
			cf.ap_sec_wpaphrase_len.value=getObj("textWpaPwdPhrase").value.length;
	        cf.hidden_wpa_ap_psk.value = cf.ap_sec_phrase.value;
	        cf.submit();
		}
}

function set_ap_security(cf)
{  
	cf.time_stamp_dni.value=parent.index_ts;
	var browser=eval ( '"' + top.location + '"' );
	var keytype;
	if  ( lan_dhcp == 1 && dns_hijack != 1)
	{
		judge_browser(cf,browser);
	}


		ssid = document.forms[0].wlan_ap_wifi.value;
	    parent.wlan_ap_wifi=ssid;
		var space_flag=0;
		if (dns_hijack==1)
		{
			var len=ssid.length;
			if(len>28)
					ssid=ssid.substring(0,28);
			document.forms[0].wlan_ca_ap_wifi.value= ssid +"_EXT";
		}
		if(ssid == "")
	        {
	                alert(ssid_null);
	                return false;
	        }
			for(i=0;i<ssid.length;i++)
	        {
	                if(isValidChar_space(ssid.charCodeAt(i))==false)
	                {
	                        alert(ssid + ssid_not_allowed);
	                        return false;
	                }
	        }
		    for(i=0;i<ssid.length;i++)
	        {
	            	if(ssid.charCodeAt(i)!=32)
	                	space_flag++;
	        }
			if(space_flag==0)
			{
				alert(ssid_null);
	        	return false;
			}
	document.forms[0].wlan_ap_wifi.value=document.forms[0].wlan_ap_wifi.value.replace(/&lt;/g,'<');
	document.forms[0].wlan_ap_wifi.value=document.forms[0].wlan_ap_wifi.value.replace(/&gt;/g,'>');
	document.forms[0].wlan_ca_ap_wifi.value=document.forms[0].wlan_ca_ap_wifi.value.replace(/&lt;/g,'<');
	document.forms[0].wlan_ca_ap_wifi.value=document.forms[0].wlan_ca_ap_wifi.value.replace(/&gt;/g,'>');
	if(parent.ap_list_reset=="manual")
	{
		if(cf.hidden_sec_ap_type.value==2)
	    {
			//if(checkwep_byid(cf)==false)
			//	return false;
	        cf.hidden_sec_ap_type.value=2;
			cf.ap_sec_wpaphrase_len.value=getObj('weppassphrase_id').value.length;
			cf.sec_auth.value=2;
			cf.hidden_sec_keylen.value=getObj("keylen_id").value;
			for(i=1;i<5;i++)
			{
				if(eval("getObj('wepkeyno_id"+i+"').checked")==true)
				cf.wepkeyno.value=i;
			}
			cf.hidden_wepkey1.value=getObj("key1_id").value;
			cf.hidden_wepkey2.value=getObj("key2_id").value;
			cf.hidden_wepkey3.value=getObj("key3_id").value;
			cf.hidden_wepkey4.value=getObj("key4_id").value;
			cf.sec_phrase.value=getObj("weppassphrase_id").value;
			var len1=document.getElementById("key1_id").value.length;
			var len2=document.getElementById("key2_id").value.length;
			var len3=document.getElementById("key3_id").value.length;
			var len4=document.getElementById("key4_id").value.length;
			if(getObj("keylen_id").value == 5)
				keytype=5;
			else
				keytype=13;
			
				for(i=0;i<keytype;i++)
				{
					if(((getObj('wepkeyno_id1').checked == true) && (len1 == keytype)) || ((getObj('wepkeyno_id2').checked == true) && (len2 == keytype)) || ((getObj('wepkeyno_id3').checked == true) && (len3 == keytype)) || ((getObj('wepkeyno_id4').checked == true) && (len4 == keytype)))
						cf.key_type.value=1;
					else
						cf.key_type.value=0;
				}
			if(old_sectype==2 && dns_hijack==0)
				alert(wep_same_security)
	        cf.submit();
	    }
		else if(cf.hidden_sec_ap_type.value!=1)
		{        
			if(cf.hidden_sec_ap_type.value==3)
				cf.ap_sec_wpaphrase.value=getObj("textWpaPwdPhrase1").value;
			else if(cf.hidden_sec_ap_type.value==4)
				cf.ap_sec_wpaphrase.value=getObj("textWpaPwdPhrase2").value;
			else if(cf.hidden_sec_ap_type.value==5)
				cf.ap_sec_wpaphrase.value=getObj("textWpaPwdPhrase3").value;
	        if( checkpsk_ca_manual(cf)== false)
	            return false;
			cf.ap_sec_wpaphrase_len.value=cf.ap_sec_wpaphrase.value.length;
	        cf.hidden_wpa_ap_psk.value = cf.ap_sec_wpaphrase.value;
			
	        cf.submit();
		}
		else
			cf.submit();
    }
	else
	{
		cf.wlan_channel.value=parent.scan_channel;
		if(cf.hidden_sec_ap_type.value==2)
	    {
			//if(checkwep_byid(cf)==false)
			//	return false;

                	if(getObj("wepkeyno_id1").checked == true)
			{
				cf.ap_wepkeyno.value = 1;
			}
			if(getObj("wepkeyno_id2").checked == true)
	                {
        	                cf.ap_wepkeyno.value = 2;
	                }
			if(getObj("wepkeyno_id3").checked == true)
                        {
                                cf.ap_wepkeyno.value = 3;
                        }
			if(getObj("wepkeyno_id4").checked == true)
                        {
                                cf.ap_wepkeyno.value = 4;
                        }
			
			cf.hidden_sec_ap_type.value=2;
			cf.ap_sec_wpaphrase_len.value=cf.ap_sec_phrase.length;
			cf.ap_sec_keylen.value=getObj("keylen_id").value;
			cf.ap_wepkey1.value=getObj("key1_id").value;
			cf.ap_wepkey2.value=getObj("key2_id").value;
			cf.ap_wepkey3.value=getObj("key3_id").value;
			cf.ap_wepkey4.value=getObj("key4_id").value;
			cf.ap_sec_phrase.value=getObj("weppassphrase_id").value;
			var len1=document.getElementById("key1_id").value.length;
			var len2=document.getElementById("key2_id").value.length;
			var len3=document.getElementById("key3_id").value.length;
			var len4=document.getElementById("key4_id").value.length;
			if(getObj("keylen_id").value == 5)
				keytype=5;
			else
				keytype=13;
			
				for(i=0;i<keytype;i++)
				{
					if(((getObj('wepkeyno_id1').checked == true) && (len1 == keytype)) || ((getObj('wepkeyno_id2').checked == true) && (len2 == keytype)) || ((getObj('wepkeyno_id3').checked == true) && (len3 == keytype)) || ((getObj('wepkeyno_id4').checked == true) && (len4 == keytype)))
						cf.key_type.value=1;
					else
						cf.key_type.value=0;
				}
			if(old_sectype==2 && dns_hijack==0)
				alert(wep_same_security)
	        cf.submit();
	    }
		else if (cf.hidden_sec_ap_type.value!=1)
		{        
	        if( checkpsk_ca_fixed(cf)== false)
	            return false;
			cf.ap_sec_wpaphrase_len.value=getObj("textWpaPwdPhrase").value.length;
	        cf.hidden_wpa_ap_psk.value = cf.ap_sec_phrase.value;
			
	        cf.submit();
		}
		else
			cf.submit();
	}
}

function chgCh(from)
{  
    var cf = document.forms[0]; 
    if ( from == 2 )
    {
		if(cf.enable_ap_client.checked==true)
		setChannel(3,1);
		else
        setChannel(1,0);
    }
    else
    {
        setwlan_mode();
		if(cf.enable_ap_client.checked==true)
		{
		    if(cf.wlan_chan.selectedIndex==0)
			setChannel(3,0);
			else
			setChannel(3,1);
		}
		else
        setChannel(1,0);
    }
}
function setwlan_mode()
{
	var cf = document.forms[0];
	var index = getObj("coun_id").selectedIndex;
	var currentMode = getObj("mode_id").selectedIndex;

	if (index == 7 || index == 8) {
		getObj("mode_id").options.length = 2;
		getObj("mode_id").options[0].text = "Up to 54Mbps";
		getObj("mode_id").options[1].text = "Up to 145Mbps";
		getObj("mode_id").options[0].value = "1";
		getObj("mode_id").options[1].value = "2";
		if (currentMode <= 1)
			getObj("mode_id").selectedIndex = currentMode;
		else
			getObj("mode_id").selectedIndex = 1;
	} else {
		getObj("mode_id").options.length = 3;
		getObj("mode_id").options[0].text = "Up to 54Mbps";
		getObj("mode_id").options[1].text = "Up to 145Mbps";
		getObj("mode_id").options[2].text = "Up to 300Mbps";
		getObj("mode_id").options[0].value = "1";
		getObj("mode_id").options[1].value = "2";
		getObj("mode_id").options[2].value = "3";
		getObj("mode_id").selectedIndex = currentMode;
	}
	return;
}

function setChannel(flag,flag2)
{
	var cf = document.forms[0];
	if(flag == 3)
	{
		var StartChannel = new Array(2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,2); 
	}
	else
	   var StartChannel = new Array(1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,1); 
	var index = getObj("coun_id").selectedIndex;
	if(flag == 3)
	{
	   var chIndex = getObj("chan_id").selectedIndex - 1;
	}
	else
	   var chIndex = getObj("chan_id").selectedIndex;
	var currentMode = getObj("mode_id").selectedIndex;
	var endChannel;

	//alert(currentMode+" "+index);
	/*if ( currentMode == 2 && (index == 4 || index == 9 ))
		endChannel = 7;	
	else if ( currentMode == 2 && index != 11)
		endChannel = 9;
	else
        */
		endChannel = FinishChannel[index];
	
	if (FinishChannel[index]==14 && getObj("mode_id").selectedIndex!=0)
		getObj("chan_id").options.length = endChannel - StartChannel[index];
	else
		getObj("chan_id").options.length = endChannel - StartChannel[index] + 2;
    
	if(flag == 3)
	{
	getObj("chan_id").options[0].text = "01";
	}
	else
	{
	getObj("chan_id").options[0].text = "Auto";
	}
	getObj("chan_id").options[0].value = 0;

	for (var i = StartChannel[index]; i <= endChannel; i++) {
		if (i==14 && getObj("mode_id").selectedIndex!=0)
			continue;
		getObj("chan_id").options[i - StartChannel[index] + 1].value = i;
		getObj("chan_id").options[i - StartChannel[index] + 1].text = (i < 10)? "0" + i : i;
	}
	if (flag2==1)
	getObj("chan_id").selectedIndex = (((chIndex > -1) && (chIndex < getObj("chan_id").options.length)) ? chIndex : 0) +1 ;
    else
	getObj("chan_id").selectedIndex = (((chIndex > -1) && (chIndex < getObj("chan_id").options.length)) ? chIndex : 0);

}

function wladv_apply()
{
	var cf=document.forms[0];
	cf.time_stamp_dni.value=parent.index_ts;
/*
	if(getObj("enable_ap").checked == true)
		cf.hidden_ap_mode.value=1;
	else
		cf.hidden_ap_mode.value=0;
	if(getObj("ssid_broad").checked == true)
		cf.hidden_endis_ssid_broadcast.value=1;
	else
		cf.hidden_endis_ssid_broadcast.value=0;
	if(getObj('endis_id').checked==true)
		cf.hidden_endis_wps.value = 1;
	else
		cf.hidden_endis_wps.value = 0;
	if(getObj('keep_id').checked==true)
		cf.hidden_keep_exist.value=5;
	else
		cf.hidden_keep_exist.value=1;
*/
        if(cf.enable_ap.checked == true)
                cf.hidden_ap_mode.value=1;
        else
                cf.hidden_ap_mode.value=0;
        if(cf.endis_ssid_broadcast.checked == true)
                cf.hidden_endis_ssid_broadcast.value=1;
        else
                cf.hidden_endis_ssid_broadcast.value=0;
        if(cf.endis_wps.checked==true)
                cf.hidden_endis_wps.value = 1;
        else
                cf.hidden_endis_wps.value = 0;
        if(cf.keep_exist.checked==true)
                cf.hidden_keep_exist.value=5;
        else
                cf.hidden_keep_exist.value=1;

}

function check_wlan()
{
	var cf=document.forms[0];
	cf.time_stamp_dni.value=parent.index_ts;
	cf.hidden_wlan_ap_wifi.value=wlan_ap_wifi;
	var ssid;
	var keytype;

/*		if(getObj("transmit").checked == true)
		{
		    cf.hidden_enable_ap_transmit.value=1;
		}
		else */
//		{ 
			ssid = getObj("ESSID").value;
		    	cf.hidden_enable_ap_transmit.value=0;
			if(ssid == "")
	        	{
	                	alert(ssid_null);
	                	return false;
	        	}
			for(i=0;i<ssid.length;i++)
	        	{
	                	if(isValidChar_space(ssid.charCodeAt(i))==false)
	                	{
	                        	alert(ssid + ssid_not_allowed);
	                        	return false;
	                	}
	        	}
		    	for(i=0;i<ssid.length;i++)
	        	{
	            		if(ssid.charCodeAt(i)!=32)
	                		space_flag++;
	        	}
			if(space_flag==0)
			{
				alert(ssid_null);
	        		return false;
			}
//		}
	        
			var ap_transmit=cf.hidden_enable_ap_transmit.value;
			
			document.forms[0].hidden_wlan_ssid.value=getObj("ESSID").value;
			var space_flag=0
			
		if(ap_transmit=="0")
		{		
					
			if(getObj("type_id2").checked== true)
			{
				if( checkwep_byid(cf)== false)
					return false;
				cf.hidden_sec_type.value=2;
			}
			else if(getObj("type_id3").checked == true)
			{
				if( checkpsk(cf)== false)
					return false;
				if(confirm(wpa_tkip_pop_message) == false)
					return false;
				cf.hidden_sec_type.value=3;
				cf.hidden_wpa_psk.value = getObj("textWpaPwdPhrase1").value;
			}
			else if(getObj("type_id4").checked == true)
			{
				if( checkpsk(cf)== false)
					return false;
				cf.hidden_sec_type.value=4;
				cf.hidden_wpa_psk.value = getObj("textWpaPwdPhrase2").value;
			}	
			else if(getObj("type_id5").checked == true)
			{
				if( checkpsk(cf)== false)
					return false;
				if(confirm(wpa_mixed_pop_message) == false)
					return false;
				cf.hidden_sec_type.value=5;
				cf.hidden_wpa_psk.value = getObj("textWpaPwdPhrase3").value;
			}	
			else
				cf.hidden_sec_type.value=1;
		}


		if(ap_transmit=="0")
		{
			cf.hidden_sec_auth.value = 2;
			cf.hidden_sec_keylen.value = getObj("keylen_id").value;
			    if(getObj("wepkeyno_id1").checked == true)
			        keyno_wep=1;
				else if(getObj("wepkeyno_id2").checked == true)
			        keyno_wep=2;
				else if(getObj("wepkeyno_id3").checked == true)
			        keyno_wep=3;
				else
					keyno_wep=4;
			cf.hidden_wepkeyno.value = keyno_wep;
			cf.hidden_wepkey1.value = getObj("key1_id").value;
			cf.hidden_wepkey2.value = getObj("key2_id").value;
			cf.hidden_wepkey3.value = getObj("key3_id").value;
			cf.hidden_wepkey4.value = getObj("key4_id").value;
			cf.hidden_weppassphrase.value = getObj("weppassphrase_id").value;
			var len1=document.getElementById("key1_id").value.length;
			var len2=document.getElementById("key2_id").value.length;
			var len3=document.getElementById("key3_id").value.length;
			var len4=document.getElementById("key4_id").value.length;
			if(getObj("keylen_id").value == 5)
				keytype=5;
			else
				keytype=13;
			
				for(i=0;i<keytype;i++)
				{
					if(((getObj('wepkeyno_id1').checked == true) && (len1 == keytype)) || ((getObj('wepkeyno_id2').checked == true) && (len2 == keytype)) || ((getObj('wepkeyno_id3').checked == true) && (len3 == keytype)) || ((getObj('wepkeyno_id4').checked == true) && (len4 == keytype)))
						cf.key_type.value=1;
					else
						cf.key_type.value=0;
				}
		}
		if(getObj("contry_id").value == "3" || getObj("contry_id").value == "8" || getObj("contry_id").value == "10")
		{
			if(get_channel > 11)	
				cf.get_chan.value=11;
			else 
				cf.get_chan.value=get_channel;
		}
		else
			cf.get_chan.value=get_channel;
		cf.hidden_region.value=getObj("contry_id").value;		
		if( cf.hidden_region.value == 12 )
		{
			alert(coun_select);
			return false;
		}

		cf.hidden_wlan_mode.value = getObj("mode_id").value;
	return true;	
}
function check_ca_wlan()
{
	var cf=document.forms[0];
	cf.time_stamp_dni.value=parent.index_ts;
	var ssid;
	cf.key_type.value=key_type;
	if(cf.use_same_sec.checked == false)
	{
		    ssid = getObj("ESSID").value;
		    cf.hidden_enable_ap_transmit.value=0;
			if(ssid == "")
	        {
	                alert(ssid_null);
	                return false;
	        }
			for(i=0;i<ssid.length;i++)
	        {
	                if(isValidChar_space(ssid.charCodeAt(i))==false)
	                {
	                        alert(ssid + ssid_not_allowed);
	                        return false;
	                }
	        }
		    for(i=0;i<ssid.length;i++)
	        {
	            	if(ssid.charCodeAt(i)!=32)
	                	space_flag++;
	        }
			if(space_flag==0)
			{
				alert(ssid_null);
	        	return false;
			}		
			document.forms[0].hidden_wlan_ssid.value=getObj("ESSID").value;

			if(cf.use_same_sec.checked == true)
				cf.hidden_same_sec.value=1;
			else
				cf.hidden_same_sec.value=0;
			var space_flag=0
					
			if(getObj("type_id2").checked== true)
			{
				if( checkwep_byid(cf)== false)
					return false;
				cf.hidden_sec_type.value=2;
			}
			else if(getObj("type_id3").checked == true)
			{
				if( checkpsk(cf)== false)
					return false;
				if(confirm(wpa_tkip_pop_message) == false)
					return false;
				cf.hidden_sec_type.value=3;
				cf.hidden_wpa_psk.value = getObj("textWpaPwdPhrase1").value;
			}
			else if(getObj("type_id4").checked == true)
			{
				if( checkpsk(cf)== false)
					return false;
				cf.hidden_sec_type.value=4;
				cf.hidden_wpa_psk.value = getObj("textWpaPwdPhrase2").value;
			}	
			else if(getObj("type_id5").checked == true)
			{
				if( checkpsk(cf)== false)
					return false;
				if(confirm(wpa_mixed_pop_message) == false)
					return false;
				cf.hidden_sec_type.value=5;
				cf.hidden_wpa_psk.value = getObj("textWpaPwdPhrase3").value;
			}	
			else
				cf.hidden_sec_type.value=1;


		
			cf.hidden_sec_auth.value = 2;
			if(getObj("keylen_id").value == "")
				cf.hidden_sec_keylen.value = 5;
			else
				cf.hidden_sec_keylen.value = getObj("keylen_id").value;
			    if(getObj("wepkeyno_id1").checked == true)
			        keyno_wep=1;
				else if(getObj("wepkeyno_id2").checked == true)
			        keyno_wep=2;
				else if(getObj("wepkeyno_id3").checked == true)
			        keyno_wep=3;
				else
					keyno_wep=4;
			cf.hidden_wepkeyno.value = keyno_wep;
			cf.hidden_wepkey1.value = getObj("key1_id").value;
			cf.hidden_wepkey2.value = getObj("key2_id").value;
			cf.hidden_wepkey3.value = getObj("key3_id").value;
			cf.hidden_wepkey4.value = getObj("key4_id").value;
			cf.hidden_wepkey1.value=document.getElementsByName("wepkey1")[0].value;
			cf.hidden_wepkey2.value=document.getElementsByName("wepkey2")[0].value;
			cf.hidden_wepkey3.value=document.getElementsByName("wepkey3")[0].value;
			cf.hidden_wepkey4.value=document.getElementsByName("wepkey4")[0].value;
			if(getObj("weppassphrase_id").value!="")
				cf.hidden_weppassphrase.value = getObj("weppassphrase_id").value;
	}
	else
	{
		if(old_sectype == 2)
		{
			cf.hidden_sec_type.value=2;	
			cf.hidden_wepkeyno.value = wl_temp_keyno;
		}
		else if(old_sectype == 3)
		{
			if(confirm(wpa_tkip_pop_message) == false)
                return false;
			cf.hidden_sec_type.value=3;
			cf.hidden_wpa_psk.value = get_wpa1;
		}
		else if(old_sectype == 4)
		{
			cf.hidden_sec_type.value=4;
			cf.hidden_wpa_psk.value = get_wpa2;
		}
		else if(old_sectype == 5)
		{
			if(confirm(wpa_mixed_pop_message) == false)
                return false;
			cf.hidden_sec_type.value=5;
			cf.hidden_wpa_psk.value = get_wpas;
		}
		else
			cf.hidden_sec_type.value=1;

		cf.hidden_sec_auth.value = 2;
		cf.hidden_sec_keylen.value = key_length;
		//cf.hidden_wepkeyno.value = 1;
		if(key_length == 5)
		{
			cf.hidden_wepkey1.value = wep_64_key1;
			cf.hidden_wepkey2.value = wep_64_key2;
			cf.hidden_wepkey3.value = wep_64_key3;
			cf.hidden_wepkey4.value = wep_64_key4;
		}
		else if(key_length == 13)
		{
                        cf.hidden_wepkey1.value = wep_128_key1;
                        cf.hidden_wepkey2.value = wep_128_key2;
                        cf.hidden_wepkey3.value = wep_128_key3;
                        cf.hidden_wepkey4.value = wep_128_key4;
		}
		document.forms[0].hidden_wlan_ssid.value=getObj("ESSID").value;
	}
	return true;	
}
