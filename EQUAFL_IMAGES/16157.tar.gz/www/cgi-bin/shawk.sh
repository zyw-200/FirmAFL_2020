#!/bin/sh

# usage: shawk.sh -F: -n3 "a b c d e"  ==> output: c
# version: 0.0.2

myawk ()
{
	case $1 in
		-F*)	field=$1
			shift
			;;
		-n*)	num=$1
			shift
			;;
	esac

	case $1 in
		-F*)	field=$1
			shift
			;;
		-n*)	num=$1
			shift
			;;
	esac

	[ "$field" = "" ] || field=$(echo $field | sed 's/-F//')
	num=$(echo $num | sed 's/-n//')
#	echo "$field,$num"

	if [ "$field" = "/" ]; then
		args=$(echo "$*" | sed "s@$field@ @g")
	elif [ "$field" != "" ]; then
		args=$(echo "$*" | sed "s/$field/ /g")
	else
		args="$*"
	fi

	count=1
	for line in $args
	do
		if [ "$num" != "NF" ]; then
			[ "$count" = "$num" ] && break
			count=$(($count+1))
		fi
	done

	if [ "$num" = "NF" -o "$count" = "$num" ]; then
		echo $line
	else
		echo ""
	fi
}

#file_num=$#
#file=${file_num}
file=$3
cat $file | while read line
do
	myawk $1 $2 $line
done

