#!/bin/sh

NVRAM="/usr/sbin/nvram"

telnet_start()
{
	if [ "x$($NVRAM get endis_telnet)" = "x1" ]; then
		/usr/sbin/utelnetd -d
	fi
}

telnet_stop()
{
	/usr/bin/killall utelnetd
}

case "$1" in
	start)
		telnet_start
	;;
	stop)
		telnet_stop
	;;
	restart)
		telnet_stop
		telnet_start
	;;
	*)
		logger -- "usage: $0 start|stop|restart"
	;;
esac 
