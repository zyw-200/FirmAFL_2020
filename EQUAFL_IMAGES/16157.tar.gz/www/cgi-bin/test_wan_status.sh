#!/bin/sh
# test if route has valid Internet connection

SUCC_FILE=/tmp/determine_wan_success
FAIL_FILE=/tmp/determine_wan_fail

#nvram=/usr/sbin/nvram


if [ -f $SUCC_FILE ];then
	rm -f $SUCC_FILE
fi
if [ -f $FAIL_FILE ];then
	rm -f $FAIL_FILE
fi


nvram=/usr/sbin/nvram
wan_status="down"

ping -c 1 updates1.netgear.com > /tmp/netgear_ping
ping_ok=`cat /tmp/netgear_ping | grep "data bytes" `
rm /tmp/netgear_ping
if [ "x$ping_ok" != "x" ];then
    wan_status="up"
fi


if [ "$wan_status" = "down" ]; then
	echo "There is not an active internet connection!" > /dev/console
	touch $FAIL_FILE
else
	echo "There is an active internet connection!" > /dev/console
	touch $SUCC_FILE
	/www/cgi-bin/webupgrade_get_confile.sh "$1" &> /dev/null &
fi

#sleep 12
#rm -f $SUCC_FILE
#rm -f $FAIL_FILE
