#!/bin/sh
. /www/cgi-bin/functions.sh
. /www/cgi-bin/webupgrade.sh
. /www/cgi-bin/change_language.sh

write_webupgrade_status_of_download_language_table $STATUS_INITIALIZING
get_ctl_file_language_table_parameters $CTL_FILE_CLN 

write_webupgrade_status_of_download_language_table $STATUS_0_PERCENT
#/www/cgi-bin/dl_ratio.cgi "$g_language_table_size" "$LANGUAGE_TABLE_FILE" &
check_webupgrade_cancelled_in_download_language_table
oc rm -f $LANGUAGE_TABLE_FILE
if ! oc /bin/snarf "$NETGEAR_SITE_1$g_language_table_path" "$LANGUAGE_TABLE_FILE"; then
	check_webupgrade_cancelled_in_download_language_table
	#if ! oc /bin/snarf "$NETGEAR_SITE_2$g_language_table_path" "$LANGUAGE_TABLE_FILE"; then
	#	check_webupgrade_cancelled_in_download_language_table
	#	if ! oc /bin/snarf "$NETGEAR_SITE_3$g_language_table_path" "$LANGUAGE_TABLE_FILE"; then
			echo "2" > /tmp/language_change_status # 1: No Internet Connection 2: Download failed
			giveup_webupgrade_in_download_language_table $STATUS_DOWNLOAD_ERROR
	#	fi
	#fi
fi
write_webupgrade_status_of_download_language_table $STATUS_100_PERCENT
#/usr/bin/killall dl_ratio.cgi

lang_md5_com=`md5sum $LANGUAGE_TABLE_FILE`
lang_md5=`echo $lang_md5_com | awk '{print tolower($1)}'`

if [ "$g_language_table_md5" != "$lang_md5" ];then
        echo "md5 checksum error!" > /dev/console
        echo "2" > /tmp/language_change_status
fi

check_webupgrade_cancelled_in_download_language_table
write_webupgrade_status_of_download_language_table $STATUS_FINISH

#/bin/mv $LANGUAGE_TABLE_FILE $PRE_LANGUAGE_TABLE
#language_table_upgrade
