config_dhcp()
{
	$nvram set dhcp_start=$2
	$nvram set dhcp_end=$3
	if [ $1 -eq 1 ]; then
		$nvram set enable_dhcpd=0		
	else
		$nvram set enable_dhcpd=1
	fi
}
config_ether()
{
	if [ $1 -eq 1 ]; then
		$nvram set lan_dhcp=0
		$nvram set lan_ipaddr=$2
		$nvram set lan_netmask=$3
		$nvram set lan_gateway=$4
		$nvram set lan_ether_dns1=$5
	else
		$nvram set lan_dhcp=1
	fi		
	$nvram set run_test="$6"
	#$nvram set port_speed=$9
}
active_lan()
{
    dhcp_enable=$($nvram get lan_dhcp)
    if [ "$dhcp_enable" = "0" ]; then
        killall udhcpc
        /sbin/ifconfig br0 "$($nvram get lan_ipaddr)" netmask "$($nvram get lan_netmask)"
    else
        killall udhcpc
        /sbin/ifconfig br0 0.0.0.0
        /sbin/udhcpc -i br0 &
    fi
}

