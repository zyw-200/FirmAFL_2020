config_secoff()
{
    echo 1 > /tmp/ca_ipchange
    $nvram set wl_sectype=1
}

config_ap_secoff()
{
    $nvram set sta_wl_sectype=1
}
config_secwep() #$1: authentication 0--mix 1--open 2--share
                #$2: wep key length 5,13
                #$3: wep key number 1,2,3,4
                #$4~$7: wep key 1~4
{
    echo 1 > /tmp/ca_ipchange
    $nvram set wl_sectype=2
    $nvram set wl_auth=2
    $nvram set key_length=$2
    $nvram set wl_key=$3
    $nvram set wl_key1="$4"
    $nvram set wl_key2="$5"
    $nvram set wl_key3="$6"
    $nvram set wl_key4="$7"
    $nvram set weppassphrase="$8"
	$nvram set wl_key_type=$9
    if [ "$2" = "5" ]; then
        $nvram set wep_64_key1="$4"
        $nvram set wep_64_key2="$5"
        $nvram set wep_64_key3="$6"
        $nvram set wep_64_key4="$7"
    else
        $nvram set wep_128_key1="$4"
        $nvram set wep_128_key2="$5"
        $nvram set wep_128_key3="$6"
        $nvram set wep_128_key4="$7"
    fi
}

config_secwep_key() #$1: authentication 0--mix 1--open 2--share
                #$2: wep key length 5,13
                #$3: wep key number 1,2,3,4
                #$4~$7: wep key 1~4
{
#   echo 1 > /tmp/ca_ipchange
#   $nvram set wl_sectype=2
    $nvram set wl_auth=2
    $nvram set key_length=$2
    $nvram set wl_key=$3
    $nvram set wl_key1="$4"
    $nvram set wl_key2="$5"
    $nvram set wl_key3="$6"
    $nvram set wl_key4="$7"
    $nvram set weppassphrase="$8"
    if [ "$2" = "5" ]; then
        $nvram set wep_64_key1="$4"
        $nvram set wep_64_key2="$5"
        $nvram set wep_64_key3="$6"
        $nvram set wep_64_key4="$7"
    else
        $nvram set wep_128_key1="$4"
        $nvram set wep_128_key2="$5"
        $nvram set wep_128_key3="$6"
        $nvram set wep_128_key4="$7"
    fi
}


config_secwpa() #$1: security type: 2--wpa-psk 3--wpa2-psk 4--wpas-psk
                #$2: passphrase
{
    echo 2 > /tmp/ca_ipchange
    $nvram set wl_sectype="$1"
    if [ $1 -eq 3 ]; then
		$nvram set wl_wpa1_psk="$2"
    elif [ $1 -eq 4 ]; then
		$nvram set wl_wpa2_psk="$2"
    else
		$nvram set wl_wpas_psk="$2"
    fi
	$nvram set wl_sec_wpaphrase_len=$3
}

config_temp_secoff()
{
    echo 1 > /tmp/ca_ipchange
    $nvram set wl_temp_sectype=1
}

config_temp_secwep() #$1: authentication 0--mix 1--open 2--share
                #$2: wep key length 5,13
                #$3: wep key number 1,2,3,4
                #$4~$7: wep key 1~4
{
    $nvram set wl_temp_sectype=2
    $nvram set wl_temp_auth=$1
    $nvram set key_temp_length=$2
    $nvram set wl_temp_key=$3
    $nvram set wl_temp_key1="$4"
    $nvram set wl_temp_key2="$5"
    $nvram set wl_temp_key3="$6"
    $nvram set wl_temp_key4="$7"
    $nvram set temp_weppassphrase="$8"
    if [ "$2" = "5" ]; then
        $nvram set wep_temp_64_key1="$4"
        $nvram set wep_temp_64_key2="$5"
        $nvram set wep_temp_64_key3="$6"
        $nvram set wep_temp_64_key4="$7"
    else
        $nvram set wep_temp_128_key1="$4"
        $nvram set wep_temp_128_key2="$5"
        $nvram set wep_temp_128_key3="$6"
        $nvram set wep_temp_128_key4="$7"
    fi
}
config_temp_secwpa() #$1: security type: 2--wpa-psk 3--wpa2-psk 4--wpas-psk
                #$2: passphrase
{
    echo 2 > /tmp/ca_ipchange
    $nvram set wl_temp_sectype="$1"
    if [ $1 -eq 3 ]; then
		$nvram set wl_temp_wpa1_psk="$2"
    elif [ $1 -eq 4 ]; then
		$nvram set wl_temp_wpa2_psk="$2"
    else
		$nvram set wl_temp_wpas_psk="$2"
    fi
	$nvram set wl_temp_sec_wpaphrase_len=$3
}

config_secwep_ap() #$1: authentication 0--mix 1--open 2--share
                #$2: wep key length 5,13
                #$3: wep key number 1,2,3,4
                #$4~$7: wep key 1~4
{
    $nvram set sta_wl_sectype=2
    $nvram set sta_wl_auth=$1
    $nvram set sta_wl_key_length=$2
    $nvram set sta_wl_key=$3
    $nvram set sta_wl_key1="$4"
    $nvram set sta_wl_key2="$5"
    $nvram set sta_wl_key3="$6"
    $nvram set sta_wl_key4="$7"
    $nvram set sta_wl_weppassphrase="$8"
	$nvram set sta_wl_key_type=$9
    if [ "$2" = "5" ]; then
        $nvram set sta_wl_wep_64_key1="$4"
        $nvram set sta_wl_wep_64_key2="$5"
        $nvram set sta_wl_wep_64_key3="$6"
        $nvram set sta_wl_wep_64_key4="$7"
    else
        $nvram set sta_wl_wep_128_key1="$4"
        $nvram set sta_wl_wep_128_key2="$5"
        $nvram set sta_wl_wep_128_key3="$6"
        $nvram set sta_wl_wep_128_key4="$7"
    fi
}
config_secwpa_ap() #$1: security type: 2--wpa-psk 3--wpa2-psk 4--wpas-psk
                #$2: passphrase
{
    $nvram set sta_wl_sectype="$1"

    if [ $1 -eq 3 ]; then
		$nvram set sta_wl_wpa1_psk="$2"
    elif [ $1 -eq 4 ]; then
		$nvram set sta_wl_wpa2_psk="$2"
    else
		$nvram set sta_wl_wpas_psk="$2"
    fi
        $nvram set wl_sec_wpaphrase_len=$3
}

