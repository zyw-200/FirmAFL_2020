#!/bin/sh
# test if route has valid Internet connection
. /www/cgi-bin/functions.sh

SUCC_FILE=/tmp/determine_wan_success
FAIL_FILE=/tmp/determine_wan_fail

nvram=/usr/sbin/nvram
wan_status="down"

ping -c 1 www.netgear.com > /tmp/netgear_ping
ping_ok=`cat /tmp/netgear_ping | grep "data bytes" `
rm /tmp/netgear_ping
if [ "x$ping_ok" != "x" ];then
    wan_status="up"
fi


if [ "$wan_status" = "up" ]; then
	touch $SUCC_FILE
    /www/cgi-bin/webupgrade_get_confile.sh "language"
	sleep 1
    oc /sbin/language_table change
else
	touch $FAIL_FILE
	echo "1" > /tmp/language_change_status # 1: No Internet Connection 2: Download failed
fi

sleep 10
rm -f $SUCC_FILE
rm -f $FAIL_FILE
