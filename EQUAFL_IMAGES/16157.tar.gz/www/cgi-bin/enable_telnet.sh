config_enable_telnet()
{
		$nvram set endis_telnet=$1	
}

